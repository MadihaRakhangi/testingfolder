import pandas as pd
import pandas as pd
import matplotlib.pyplot as plt
import docx
import csv
import io
from docx.shared import Inches
from docx.shared import Pt

af = pd.read_csv("final.csv")
bf = pd.read_csv("location.csv")
cf = pd.read_csv("id.csv")

df = pd.merge(bf, cf, on='id', how='left')
df.to_csv("combined.csv", index=False)


def result(af, df):
        location = []
        for index, row in df.iterrows():
                if row["loc_id"] == row["id"]:
                        cell_value = af.loc[ : "loc_name"]  
                        location.append(cell_value)
                        print(location)
                else:
                        location.append("NA")
                        print(location)
      

